> Animate.css v4 brought some **breaking changes**, please refer to the [migration guide](#migration) before updating from v3.x and under.

**Animate.css** is a library of ready-to-use, cross-browser animations for use in your web projects. Great for emphasis, home pages, sliders, and attention-guiding hints.
